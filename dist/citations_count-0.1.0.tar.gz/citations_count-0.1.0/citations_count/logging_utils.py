def log_message(message: str, verbose: bool):
    if verbose:
        print(message)